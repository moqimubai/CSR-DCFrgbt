from .features import GrayFeature,FHogFeature, TableFeature, fhog, mround, ResNet50Feature, VGG16Feature

import os
import cv2
from PIL import Image
import numpy as np

from cftracker.csrdcf import CSRDCF
from cftracker.config import csrdcf_config


def get_sequence(seq,seq_home):
    result_home='../MANet-RGBT234_result' # you need creat result dirpath
    img_dir1=os.path.join(seq_home,seq,'visible')
    img_dir2=os.path.join(seq_home,seq,'infrared')
    gt_path=os.path.join(seq_home,seq,'visible.txt')
    img_list1=os.listdir(img_dir1)
    img_list1.sort()
    img_list1=[os.path.join(img_dir1,x) for x in img_list1]
    img_list2=os.listdir(img_dir2)
    img_list2.sort()
    img_list2=[os.path.join(img_dir2,x) for x in img_list2]
    with open(gt_path) as f:
        gt=np.loadtxt((x.replace(',',' ')for x in f))
    init_bbox=gt[0]

    result_dir=os.path.join(result_home)
    if not os.path.exists(result_dir):
        os.makedirs(result_dir)
    result_path=os.path.join(result_dir,'CSRDCF_'+seq+'.txt')
    return img_list1,img_list2,init_bbox,gt,result_path

if __name__ == '__main__':




    list_path = os.path.join('rgbt234.txt')
    res_dir = '/home/ldd/Track/pyCFTrackers-master/examples/CSRDCF-RGBT234_result/'  # you need creat result dirpath
    data_dir = '/home/ldd/Track/trackdat-master/data/RGBT-234/'  # set tracking dataset path
    seqs = []

    total_fps = 0
    with open(list_path) as f:
        content = f.readlines()
    for line in content:
        parsed_line = line.split()
        seqs.append(parsed_line[0])

    n_seq = len(seqs)
    for i in range(n_seq):
        seq = seqs[i]
        print(i, seq)
        if 'CSRDCF_' + seq + '.txt' not in os.listdir(res_dir):
            img_list1, img_list2, init_gt, gt, result_path = get_sequence(seq, data_dir)
        tracker = CSRDCF(config=csrdcf_config.CSRDCFConfig())
        poses = []
        bgr_frame = cv2.imread(img_list1[0])
        t_frame = cv2.imread(img_list2[0],cv2.IMREAD_GRAYSCALE)
        b,g,r = cv2.split(bgr_frame)
        rgbt_frame = cv2.merge([r,g,b,t_frame])
        poses = []
        # print(init_frame.shape)
        x1, y1, w, h = init_gt
        poses.append(np.array([int(x1), int(y1), int(w), int(h)]))
        init_gt = tuple(init_gt)
        tracker.init(rgbt_frame, init_gt)
        for idx in range(1,len(img_list1)):
            bgr_frame = cv2.imread(img_list1[idx])
            t_frame = cv2.imread(img_list2[idx], cv2.IMREAD_GRAYSCALE)
            b, g, r = cv2.split(bgr_frame)
            rgbt_frame = cv2.merge([r, g, b, t_frame])
            bbox = tracker.update(rgbt_frame, 0)
            poses.append(np.array([int(x1), int(y1), int(w), int(h)]))
            x1, y1, w, h = bbox
            # show_frame1 = cv2.rectangle(bgr_frame, (int(x1), int(y1)), (int(x1 + w), int(y1 + h)), (255, 0, 0), 1)
            # cv2.imshow('demo1', show_frame1)
            # cv2.waitKey(1)
            # show_frame2 = cv2.rectangle(t_frame, (int(x1), int(y1)), (int(x1 + w), int(y1 + h)), (255, 0, 0), 1)
            # cv2.imshow('demo2', show_frame2)
            # cv2.waitKey(1)
        poses.append(np.array([int(x1), int(y1), int(w), int(h)]))
        result_bb = np.array(poses)
        f = open(res_dir+'CSRDCFt_'+seq+'.txt', 'w+')
        for i in range(len(result_bb)):
            res = '{} {} {} {} {} {} {} {}'.format(result_bb[i][0], result_bb[i][1],

                                                   result_bb[i][0] + result_bb[i][2], result_bb[i][1],

                                                   result_bb[i][0] + result_bb[i][2], result_bb[i][1] + result_bb[i][3],

                                                   result_bb[i][0], result_bb[i][1] + result_bb[i][3]
                                                   )
            f.write(res)
            f.write('\n')
        f.close()




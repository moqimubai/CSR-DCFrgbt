run examples/cf_rgbt_demo.py
